#pragma once
#include "pch.h"
class service1
{

private:
	c1 o1;
	c2 o2;
	c3 o3;
public:
	void gpcs1s1();
	void gpcs1s2();
};

class service2
{

private:
	c1 o4;
	c3 o5;
public:
	void gpcs2s1();
};