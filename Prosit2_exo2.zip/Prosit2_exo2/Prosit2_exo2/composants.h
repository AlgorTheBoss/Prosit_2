#pragma once
#include "pch.h"

class c1
{
public:
	void func1();
};

class c2
{
public:
	void func2();
};

class c3
{
public:
	void func3();
};