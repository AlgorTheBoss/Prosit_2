#include "pch.h"

void c1::func1()
{
	cout << "c1 ";
}
void c2::func2()
{
	cout << "c2 ";
}
void c3::func3()
{
	cout << "c3 ";
}


void service1::gpcs1s1()
{
	this->o1.func1();
	this->o2.func2();
}
void service1::gpcs1s2()
{
	this->o3.func3();
}
void service2::gpcs2s1()
{
	this->o4.func1();
	this->o5.func3();
}

