#include "pch.h"

void main(void)
{
	service1* of1;
	of1 = new service1();
	of1->gpcs1s1();
	service1* of2;
	of2 = new service1();
	of2->gpcs1s2();

	service2* of3;
	of3 = new service2();
	of3->gpcs2s1();
}